const sql = require('mssql');
const express = require('express');
const app = express();
var newUsers = []
var newGroups = []
var newTypes = []

const config = {
    server: "localhost",
    database: "AddressBook",
    user: "Narwhal",
    password: "KJB51014",
    port: 514
}

app.listen('5014', () => {
    console.log('Server Started')
})

app.get('/', (req, res) => {
    sql.connect(config).then(pool => {
        return pool.request()
        .execute('sp_SelectAllUsers')
    }).then(result => {
        var Users = result.recordset
        var userCount = Users.length
        var i = 0
        while(i < userCount){
            newUsers[i] = {
                ID: result.recordset[i].ID,
                FirstName: result.recordset[i].FirstName,
                LastName: result.recordset[i].LastName,
                Address: result.recordset[i].Adress,
                PhoneNumber:  result.recordset[i].PhoneNumber,
                Type: result.recordset[i].Name[0],
                Group: result.recordset[i].Name[1]
            }
            i++
        }
        sql.close()
    }).then(() => {
        res.header('Access-Control-Allow-Origin', '*')
        res.send(newUsers)
        newUsers = []
    }).catch(err => {
        sql.close()
        newUsers = []
    })
})

app.get('/filters/:type&:group', (req, res) => {
    sql.connect(config).then(pool => {
        if(req.params.type != 0 & req.params.group != 0){
            return pool.request().input('type',  sql.Int, req.params.type).input('group', sql.Int, req.params.group).query('SELECT Users.ID, Users.FirstName, Users.LastName, Users.[Adress], Users.PhoneNumber, PhoneKey.[Name], SingleGroup.[Name] FROM Users left join Groups as SingleGroup on Users.[Group] = SingleGroup.ID left join PhoneType as PhoneKey on Users.PhoneKey = PhoneKey.ID WHERE Users.PhoneKey = @type AND Users.[Group] = @group')
        } else if(req.params.type != 0){
            return pool.request().input('type',  sql.Int, req.params.type).query('SELECT Users.ID, Users.FirstName, Users.LastName, Users.[Adress], Users.PhoneNumber, PhoneKey.[Name], SingleGroup.[Name] FROM Users left join Groups as SingleGroup on Users.[Group] = SingleGroup.ID left join PhoneType as PhoneKey on Users.PhoneKey = PhoneKey.ID WHERE Users.PhoneKey = @type')
        } else if( req.params.group != 0){
            return pool.request().input('group', sql.Int, req.params.group).query('SELECT Users.ID, Users.FirstName, Users.LastName, Users.[Adress], Users.PhoneNumber, PhoneKey.[Name], SingleGroup.[Name] FROM Users left join Groups as SingleGroup on Users.[Group] = SingleGroup.ID left join PhoneType as PhoneKey on Users.PhoneKey = PhoneKey.ID WHERE Users.[Group] = @group')
        } else{
            return pool.request().execute('sp_SelectAllUsers')
        }
    }).then(result => {
        var Users = result.recordset
        var userCount = Users.length
        var i = 0
        while(i < userCount){
            newUsers[i] = {
                ID: result.recordset[i].ID,
                FirstName: result.recordset[i].FirstName,
                LastName: result.recordset[i].LastName,
                Address: result.recordset[i].Adress,
                PhoneNumber:  result.recordset[i].PhoneNumber,
                Type: result.recordset[i].Name[0],
                Group: result.recordset[i].Name[1]
            }
            i++
        }
        sql.close()
    }).then(() => {
        res.header('Access-Control-Allow-Origin', '*')
        res.send(newUsers)
        newUsers = []
    }).catch(err => {
        sql.close()
        newUsers = []
    })
})

app.get('/selectUser/:id', (req, res) => {
    var newUser = {}
    sql.connect(config).then(pool => {
        return pool.request()
        .input('Key',sql.Int, req.params.id)
        .execute('sp_UserSelect')
    }).then(result => {
             newUser = {
                ID: result.recordset[0].ID,
                FirstName: result.recordset[0].FirstName,
                LastName: result.recordset[0].LastName,
                Address: result.recordset[0].Adress,
                PhoneNumber:  result.recordset[0].PhoneNumber,
                Type: result.recordset[0].Name[0],
                Group: result.recordset[0].Name[1]
            }
        sql.close()
    }).then(() => {
        res.header('Access-Control-Allow-Origin', '*')
        res.send(newUser)
        newUser = {}
    }).catch(err => {
        sql.close()
    })
})

app.get('/latestUser', (req, res) => {
    var newUser = {}
    sql.connect(config).then(pool => {
        return pool.request()
        .execute('sp_SelectLatestUser')
    }).then(result => {
             newUser = {
                ID: result.recordset[0].ID,
                FirstName: result.recordset[0].FirstName,
                LastName: result.recordset[0].LastName,
                Address: result.recordset[0].Adress,
                PhoneNumber:  result.recordset[0].PhoneNumber,
                Type: result.recordset[0].Name[0],
                Group: result.recordset[0].Name[1]
            }
        sql.close()
    }).then(() => {
        res.header('Access-Control-Allow-Origin', '*')
        res.send(newUser)
        newUser = {}
    }).catch(err => {
        sql.close()
    })
})

app.get('/groups', (req, res) => {
    sql.connect(config).then(pool => {
        return pool.request()
        .execute('sp_SelectAllGroups')
    }).then(result => {
        var Groups = result.recordset
        var groupCount = Groups.length
        var i = 0
        while(i < groupCount){
            newGroups[i] = {
                ID: Groups[i].id,
                Name: Groups[i].Name
            }
            i++
        }
        sql.close()
        res.header('Access-Control-Allow-Origin', '*')
        res.send(newGroups)
        newGroups = []
    }).catch(err => {
        sql.close()
    })
})

app.get('/types', (req, res) => {
    sql.connect(config).then(pool => {
        return pool.request()
        .execute('sp_SelectAllPhoneTypes')
    }).then(result => {
        var Types = result.recordset
        var typeCount = Types.length
        var i = 0
        while(i < typeCount){
            newTypes[i] = {
                ID: Types[i].id,
                Name: Types[i].Name
            }
            i++
        }
        sql.close()
        res.header('Access-Control-Allow-Origin', '*')
        res.send(newTypes)
        newTypes = []
    }).catch(err => {
        sql.close()
    })
})

app.get('/delete/:id', (req, res) => {
    sql.connect(config).then(pool => {

        return pool.request()
        .input('key', sql.Int, req.params.id)
        .execute('sp_UserDelete')
    }).then(result => {
        sql.close()
        res.header('Access-Control-Allow-Origin', '*')
        res.send("1")
    }).catch(err => {
        sql.close()
    })
})

app.get('/add/:FirstName&:LastName&:Address&:PhoneNumber&:Type&:Group', (req, res) => {
    sql.connect(config).then(pool => {

        return pool.request()
        .input('FirstName', sql.VarChar, req.params.FirstName)
        .input('LastName', sql.VarChar, req.params.LastName)
        .input('Address', sql.VarChar, req.params.Address)
        .input('PhoneNumber', sql.VarChar, req.params.PhoneNumber)
        .input('PhoneType', sql.Int, req.params.Type)
        .input('Group', sql.Int, req.params.Group)
        .execute('sp_UserAdd')
    }).then(result => {
        sql.close()
        res.header('Access-Control-Allow-Origin', '*')
        res.send("1")
    }).catch(err => {
        console.dir(err)
        sql.close()
    })
})

app.get('/update/:id&:FirstName&:LastName&:Address&:PhoneNumber&:Type&:Group', (req, res) => {
    sql.connect(config).then(pool => {

        return pool.request()
        .input('ID', sql.Int, req.params.id)
        .input('FirstName', sql.VarChar, req.params.FirstName)
        .input('LastName', sql.VarChar, req.params.LastName)
        .input('Address', sql.VarChar, req.params.Address)
        .input('PhoneNumber', sql.VarChar, req.params.PhoneNumber)
        .input('PhoneType', sql.Int, req.params.Type)
        .input('Group', sql.Int, req.params.Group)
        .execute('sp_UserUpdate')
    }).then(result => {
        sql.close()
        res.header('Access-Control-Allow-Origin', '*')
        res.send("1")
    }).catch(err => {
        console.dir(err)
        sql.close()
    })
})
