var myTable = document.getElementById("AddressTable");
var filterButton = document.getElementById("filterButton")
var typeFilterSelect = document.getElementById("typeFilter")
var groupFilterSelect = document.getElementById("groupFilter")
var searchBox = document.getElementsByName("searchBox")
var searchFilter = document.getElementById("searchParams")
var Users = []
var Count = 1
var checkOne = false
var checkTwo = false
var masterGroups = []
var masterTypes = []
var down = false

var populateOptions = function(){
    var timer = 0
    const HttpOne = new XMLHttpRequest();
    const urlOne ='http://localhost:5014/groups';
    HttpOne.open("GET", urlOne);
    HttpOne.send();
    HttpOne.onreadystatechange = function() {
    if(this.readyState == 4 && this.status == 200){
        var myGroups = JSON.parse(HttpOne.responseText)
        var i = 0
        myGroups.forEach(option => {
            var selectOption = document.createElement("option")
            selectOption.text = option.Name; selectOption.value = option.ID
            masterGroups[i] = selectOption
            i++
        });
        checkOne = true
        if(checkOne === true & checkTwo === true){
            populateFilters()
            firstRowCreation()
            populateData()
        } 
    }}

    const HttpTwo = new XMLHttpRequest();
    const urlTwo='http://localhost:5014/types';
    HttpTwo.open("GET", urlTwo);
    HttpTwo.send();
    HttpTwo.onreadystatechange = function(){
    if(this.readyState == 4 && this.status == 200){
        var myTypes = JSON.parse(HttpTwo.responseText)
        var k = 0
        myTypes.forEach(type => {
            var selectOption = document.createElement("option")
            selectOption.text = type.Name; selectOption.value = type.ID
            masterTypes[k] = selectOption
            k++
        });
        checkTwo = true
        if(checkOne === true & checkTwo === true){
            populateFilters()
            firstRowCreation()
            populateData()
        }
    }}
}

searchBox[0].addEventListener('keydown',function(event){
    if(event.keyCode == 8){
        down = true
    }
})

searchBox[0].addEventListener('keyup',function(event){
    if(down == true){
        var tableRows = document.getElementsByTagName("tr")
        var i = 2
        for(i; i < tableRows.length; i++){
            tableRows[i].hidden = true
            switch(searchFilter.selectedOptions[0].value){
                case "0":
                    if(tableRows[i].cells[1].firstElementChild.value.includes(searchBox[0].value) == true || tableRows[i].cells[2].firstElementChild.value.includes(searchBox[0].value) == true || tableRows[i].cells[3].firstElementChild.value.includes(searchBox[0].value) == true|| tableRows[i].cells[4].firstElementChild.value.replace("-", "").replace("-","").includes(searchBox[0].value) == true){
                    tableRows[i].hidden = false
                    }
                    break
                case "1": 
                if(tableRows[i].cells[1].firstElementChild.value.includes(searchBox[0].value == true)){
                    tableRows[i].hidden = false
                }
                    break
                case "2":
                if(tableRows[i].cells[2].firstElementChild.value.includes(searchBox[0].value) == true){
                    tableRows[i].hidden = false
                }
                    break
                case "3":
                if(tableRows[i].cells[3].firstElementChild.value.includes(searchBox[0].value) == true){
                    tableRows[i].hidden = false
                }
                    break
                case "4":
                if(tableRows[i].cells[4].firstElementChild.value.replace("-", "").replace("-","").includes(searchBox[0].value) == true){
                    tableRows[i].hidden = false
                }
                    break
            }
        };
        down = false
    }
})

searchBox[0].addEventListener('keypress', function(){
    var tableRows = document.getElementsByTagName("tr")
    var i = 2
    for(i; i < tableRows.length; i++){
        tableRows[i].hidden = true
        switch(searchFilter.selectedOptions[0].value){
            case "0":
                if(tableRows[i].cells[1].firstElementChild.value.includes(searchBox[0].value) == true || tableRows[i].cells[2].firstElementChild.value.includes(searchBox[0].value) == true || tableRows[i].cells[3].firstElementChild.value.includes(searchBox[0].value) == true|| tableRows[i].cells[4].firstElementChild.value.replace("-", "").replace("-","").includes(searchBox[0].value) == true){
                   tableRows[i].hidden = false
                }
                break
            case "1": 
            if(tableRows[i].cells[1].firstElementChild.value.includes(searchBox[0].value == true)){
                tableRows[i].hidden = false
             }
                break
            case "2":
            if(tableRows[i].cells[2].firstElementChild.value.includes(searchBox[0].value) == true){
                tableRows[i].hidden = false
             }
                break
            case "3":
            if(tableRows[i].cells[3].firstElementChild.value.includes(searchBox[0].value) == true){
                tableRows[i].hidden = false
             }
                break
            case "4":
            if(tableRows[i].cells[4].firstElementChild.value.replace("-", "").replace("-","").includes(searchBox[0].value) == true){
                tableRows[i].hidden = false
             }
                break
        }
    };
})

function populateFilters(){
    var typeOptions = masterTypes
    var groupOptions = masterGroups
    typeOptions.forEach(typeOption => {
        var optionToAdd = document.createElement("option")
        optionToAdd.text = typeOption.text; optionToAdd.value = typeOption.value;
        //optionToAdd.style = optionCustomization(optionToAdd.value)
        typeFilterSelect.add(optionToAdd)
    });
    //typeFilterSelect.addEventListener('click', function(){
    //    typeFilterSelect.style = optionCustomization(typeFilterSelect.selectedOptions[0].value)
    //})

    groupOptions.forEach(groupOption => {
        var optionToAdd = document.createElement("option")
        optionToAdd.text = groupOption.text; optionToAdd.value = groupOption.value;
        //optionToAdd.style = optionCustomization(optionToAdd.value)
        groupFilterSelect.add(optionToAdd)
    });
    //groupFilterSelect.addEventListener('click', function(){
    //    groupFilterSelect.style = optionCustomization(groupFilterSelect.selectedOptions[0].value)
    //})

    filterButton.addEventListener('click', function(){
        Count = 1
        var filterOne = typeFilterSelect.selectedOptions[0].value
        var filtertwo = groupFilterSelect.selectedOptions[0].value
        const Http = new XMLHttpRequest();
        const url=`http://localhost:5014/filters/${filterOne}&${filtertwo}`;
        Http.open("GET", url);
        Http.send();
        Http.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            var i = 0
            var length = myTable.rows.length
            while(i < length - 2){
                myTable.deleteRow(2)
                i++
            }
            var myUsers = JSON.parse(Http.responseText)
            myUsers.forEach(userToAdd => {
                createRow(userToAdd) 
            });
        }}
    })
}
var populateData = function(){
    const Http = new XMLHttpRequest();
    const url='http://localhost:5014/';
    Http.open("GET", url);
    Http.send();
    Http.onreadystatechange = function(){
    if(this.readyState == 4 && this.status == 200){
        var myUsers = JSON.parse(Http.responseText)
        myUsers.forEach(userToAdd => {
            createRow(userToAdd) 
        });
    }}
}

var selectUser = function(){
    const Http = new XMLHttpRequest();
        const url='http://localhost:5014/latestUser';
        Http.open("GET", url);
        Http.send();
        Http.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                var myUser = JSON.parse(Http.responseText)
                    createRow(myUser) 
            }}
}

var getUser = function(id){
    const Http = new XMLHttpRequest();
        const url=`http://localhost:5014/selectUser/${id}`;
        Http.open("GET", url);
        Http.send();
        Http.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                var myUser = JSON.parse(Http.responseText)
                    createRow(myUser) 
            }}
}

var valueCheck = function(userToCheck){
    var i = 0
    var validValues = ["1","2","3","4","5","6","7","8","9", "0"]
    if(userToCheck.LastName == null || userToCheck.LastName == ""){
        userToCheck.LastName = "NONE"
    } if(userToCheck.Address == null || userToCheck.Address == ""){
        userToCheck.Address = "NONE"
    } if(userToCheck.FirstName == null || userToCheck.FirstName == ""){
        throw new Error("First name is required")
        
    } if(userToCheck.PhoneNumber == null || userToCheck.PhoneNumber == ""){
        throw new Error("Phone number is required")
    }
    while(userToCheck.PhoneNumber.includes("-")){
        userToCheck.PhoneNumber = userToCheck.PhoneNumber.replace("-", "")
    }
    if(userToCheck.PhoneNumber.length != 10){
        throw new Error("Please enter a valid phone number")
    }
    while(i < userToCheck.PhoneNumber.length){
        if(!validValues.includes(userToCheck.PhoneNumber.substr(i, 1))){
            throw new Error("Phone number must be all numeric")
        }
        i++
    }
    return userToCheck
}

var resetUser = function(){
    var tableRows = document.getElementsByTagName("tr")
                var cells =  tableRows[1].cells
                for( k = 1; k < cells.length - 1; k++){
                    if(k == 5|| k == 6){
                        cells[k].firstElementChild.value = 1
                    } else{
                        cells[k].firstElementChild.value = ""
                    }
                }
}

function optionCustomization(num){
    var styleString
    switch(num){
        case "1":
            styleString = "font-style: italic; color: yellow; background-color: grey"
            break
        case "2":
            styleString = "font-style: italic; color: yellow; background-color: green"
            break
        case "3":
            styleString = "font-style: italic; color: yellow; background-color: red"
            break
        case "4":
            styleString = "font-style: italic; color: yellow; background-color: blue"
            break
        case "5":
            styleString = "font-style: italic; color: yellow; background-color: brown"
            break
        case "6":
            styleString = "font-style: italic; color: yellow; background-color: teal"
            break
        case "7":
            styleString = "font-style: italic; color: yellow; background-color: purple"
            break
        case "8":
            styleString = "font-style: italic; color: black; background-color: #ffc61a"
            break
        case "9":
            styleString = "font-style: italic; color: black; background-color: #ffd966"
            break
        case "10":
            styleString = "font-style: italic; color: black; background-color: greenyellow"
            break
        case "11":
            styleString = "font-style: italic; color: yellow; background-color: #884dff"
            break
        case "12":
            styleString = "font-style: italic; color: black; background-color: #ffff00"
            break
        case "13":
            styleString = "font-style: italic; color: yellow; background-color: #ff3399"
            break
        case "14":
            styleString = "font-style: italic; color: black; background-color: #66ffff"
            break
        case "15":
            styleString = "font-style: italic; color: yellow; background-color: #944dff"
            break
        case "16":
            styleString = "font-style: italic; color: yellow; background-color: #4d3319"
            break
        case "17":
            styleString = "font-style: italic; color: black; background-color: #eff5f5"
            break
        case "18":
            styleString = "font-style: italic; color: yellow; background-color: #ff66ff"
            break
        case "19":
            styleString = "font-style: italic; color: yellow; background-color: black"
            break
        default:
            styleString = "font-style: italic; color: black; background-color: white"
            break
    }
    return styleString
}

function firstRowCreation(){
    var typeOptions = masterTypes
    var groupOptions = masterGroups
    //Creating New Row
    var newRow =  myTable.insertRow(myTable.rows.length)
    
    //Creating First Cell In table and giving some styling
    var userNumber  = newRow.insertCell(0)
    userNumber.style = "text-align: center"
    var userCount = document.createTextNode("?")

    //Creating Cells in table
    var FirstName  = newRow.insertCell(1)
    var LastName  = newRow.insertCell(2)
    var Address  = newRow.insertCell(3)
    var PhoneNumber  = newRow.insertCell(4)
    var PhoneType  = newRow.insertCell(5)
    var PhoneGroup  = newRow.insertCell(6)
    var Add  = newRow.insertCell(7)
    
    //Setting Cells to TextBoxs 
    var TextBoxOne  = document.createElement("input")
    TextBoxOne.style = "width: 99%"
    var TextBoxTwo  = document.createElement("input")
    TextBoxTwo.style = "width: 99%"
    var TextBoxThree  = document.createElement("input")
    TextBoxThree.style = "width: 99%"
    var TextBoxFour  = document.createElement("input")
    TextBoxFour.style = "width: 99%"

    //Phone Type Dropdown Menu
    var SelectBoxOne  = document.createElement("select")
    typeOptions.forEach(typeOption => {
        var optionToAdd = document.createElement("option")
        optionToAdd.text = typeOption.text; optionToAdd.value = typeOption.value;
        //optionToAdd.style = optionCustomization(optionToAdd.value)
        SelectBoxOne.add(optionToAdd)
    });
    typeOptions.forEach(text => {
        if(text.text == "NONE"){
            SelectBoxOne.selectedIndex = typeOptions.indexOf(text)
        }
    });
    //SelectBoxOne.addEventListener('click', function(){
    //    SelectBoxOne.style = optionCustomization(SelectBoxOne.selectedOptions[0].value)
    //})
    //SelectBoxOne.style = optionCustomization(SelectBoxOne.selectedOptions[0].value)

    //Phone Group Dropdown Mennu
    var SelectBoxTwo  = document.createElement("select")
    groupOptions.forEach(groupOption => {
        var optionToAdd = document.createElement("option")
        optionToAdd.text = groupOption.text; optionToAdd.value = groupOption.value; 
        //optionToAdd.style = optionCustomization(optionToAdd.value)
        SelectBoxTwo.add(optionToAdd)
    });
    groupOptions.forEach(text => {
        if(text.text == "NONE"){
            SelectBoxTwo.selectedIndex = groupOptions.indexOf(text)
        }
    });
    //SelectBoxTwo.addEventListener('click', function(){
    //    SelectBoxTwo.style = optionCustomization(SelectBoxTwo.selectedOptions[0].value)
    //})
    //SelectBoxTwo.style = optionCustomization(SelectBoxTwo.selectedOptions[0].value)
    
    //Add Button Options
    var ButtonOne  = document.createElement("button")
    ButtonOne.style = "width: 99%; border: 1px solid black; border-radius: 5px; color: white; background-color:  rgb(29, 145, 1);"
    ButtonOne.id = "addButton"
    var AddText = document.createTextNode("Add")
    ButtonOne.appendChild(AddText)

    //Finalization of all cells
    userNumber.appendChild(userCount)
    FirstName.appendChild(TextBoxOne)
    LastName.appendChild(TextBoxTwo)
    Address.appendChild(TextBoxThree)
    PhoneNumber.appendChild(TextBoxFour)
    PhoneType.appendChild(SelectBoxOne)
    PhoneGroup.appendChild(SelectBoxTwo)
    Add.appendChild(ButtonOne)

    var addButton = document.getElementById("addButton");
    addButton.addEventListener("click", function(){
        try{
        var User = []
        var i = 0
        var tableRows = document.getElementsByTagName("tr")
        var cells =  tableRows[1].cells
        for( k = 1; k < cells.length - 1; k++){
            User[i] = cells[k].firstElementChild.value.toString()
            i++
        }
        var newUser = {
            FirstName: User[0],
            LastName: User[1],
            Address: User[2],
            PhoneNumber: User[3],
            Type: User[4],
            Group: User[5]
        }
        newUser = valueCheck(newUser)
        //Sending Server Request
        var check = confirm(`Would you like to add ${User[0]} ${User[1]}?`)
        if(check == true){
        const Http = new XMLHttpRequest();
        const url=`http://localhost:5014/add/${newUser.FirstName}&${newUser.LastName}&${newUser.Address}&${newUser.PhoneNumber}&${newUser.Type}&${newUser.Group}`;
        Http.open("GET", url);
        Http.send();
        Http.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                    if(Http.responseText == 1){
                        selectUser()
                        resetUser() 
                        alert("User Added Successfuly")
                    } else{
                        alert("User Failed to add...")
                    }
            }   }
        }
        }catch(err){
            alert(err)
        }
    });

}

var createRow = function(data){
    var typeOptions = masterTypes
    var groupOptions = masterGroups
    //Creating New Row
    var newRow =  myTable.insertRow(myTable.rows.length)
    
    //Creating First Cell In table and giving some styling
    var userNumber  = newRow.insertCell(0)

    userNumber.style = "text-align: center"
    var userCount = document.createTextNode(Count.toString())

    //Creating Cells in table
    var FirstName  = newRow.insertCell(1)
    var LastName  = newRow.insertCell(2)
    var Address  = newRow.insertCell(3)
    var PhoneNumber  = newRow.insertCell(4)
    var PhoneType  = newRow.insertCell(5)
    var PhoneGroup  = newRow.insertCell(6)
    var id = newRow.insertCell(7)
    var Delete  = newRow.insertCell(8)
    var Update  = newRow.insertCell(9)
    id.hidden = true
    
    //Setting Cells to TextBoxs 
    var TextBoxOne  = document.createElement("input")
    TextBoxOne.style = "width: 99%"
    TextBoxOne.value = data.FirstName
    var TextBoxTwo  = document.createElement("input")
    TextBoxTwo.style = "width: 99%"
    TextBoxTwo.value = data.LastName
    var TextBoxThree  = document.createElement("input")
    TextBoxThree.style = "width: 99%"
    TextBoxThree.value = data.Address
    var TextBoxFour  = document.createElement("input")
    TextBoxFour.style = "width: 99%"
    data.PhoneNumber = `${data.PhoneNumber.substring(0, 3)}-${data.PhoneNumber.substring(3, 6)}-${data.PhoneNumber.substring(6, 10)}`
    TextBoxFour.value = data.PhoneNumber
    var TextBoxFive  = document.createElement("input")
    TextBoxFive.style = "width: 99%"
    TextBoxFive.value = data.ID

    //Phone Type Dropdown Menu
    var SelectBoxOne  = document.createElement("select")
    typeOptions.forEach(typeOption => {
        var optionToAdd = document.createElement("option")
        optionToAdd.text = typeOption.text; optionToAdd.value = typeOption.value;
        //optionToAdd.style = optionCustomization(optionToAdd.value)
        SelectBoxOne.add(optionToAdd)
    });
    typeOptions.forEach(text => {
        if(text.text == data.Type){
            SelectBoxOne.selectedIndex = typeOptions.indexOf(text)
        }
    });
    //SelectBoxOne.addEventListener('click', function(){
    //    SelectBoxOne.style = optionCustomization(SelectBoxOne.selectedOptions[0].value)
    //})
    //SelectBoxOne.style = optionCustomization(SelectBoxOne.selectedOptions[0].value)

    //Phone Group Dropdown Mennu
    var SelectBoxTwo  = document.createElement("select")
    groupOptions.forEach(groupOption => {
        var optionToAdd = document.createElement("option")
        optionToAdd.text = groupOption.text; optionToAdd.value = groupOption.value;
        //optionToAdd.style = optionCustomization(optionToAdd.value)
        SelectBoxTwo.add(optionToAdd)
    });
    groupOptions.forEach(newOption => {
        if(newOption.text == data.Group){
            SelectBoxTwo.selectedIndex = groupOptions.indexOf(newOption)
        }
    });
    //SelectBoxTwo.addEventListener('click', function(){
    //    SelectBoxTwo.style = optionCustomization(SelectBoxTwo.selectedOptions[0].value)
    //})
    //SelectBoxTwo.style = optionCustomization(SelectBoxTwo.selectedOptions[0].value)
    
    //Delete Button Options
    var ButtonOne  = document.createElement("button")
    ButtonOne.style = "width: 99%; border: 1px solid black; border-radius: 5px; color: white; Background-color: rgb(255, 6, 6);"
    ButtonOne.id = "DeleteButton" + Count
    var DeleteText = document.createTextNode("Delete")
    ButtonOne.appendChild(DeleteText)
    ButtonOne.value = Count


    //Update Button Options
    var ButtonTwo  = document.createElement("button")
    ButtonTwo.style = "width: 99%; border: 1px solid black; border-radius: 5px; color: white; Background-color: rgb(38, 153, 247);"
    ButtonTwo.id = "UpdateButton" + Count
    var UpdateText = document.createTextNode("Update")
    ButtonTwo.appendChild(UpdateText)

    //Finalization of all cells
    userNumber.appendChild(userCount)
    FirstName.appendChild(TextBoxOne)
    LastName.appendChild(TextBoxTwo)
    Address.appendChild(TextBoxThree)
    PhoneNumber.appendChild(TextBoxFour)
    PhoneType.appendChild(SelectBoxOne)
    PhoneGroup.appendChild(SelectBoxTwo)
    id.appendChild(TextBoxFive)
    Delete.appendChild(ButtonOne)
    Update.appendChild(ButtonTwo)
    eventCreation()
    Count++
}

var eventCreation = function(){
    var element = "DeleteButton" + Count
    var deleteUserButton = document.getElementById(element)
    deleteUserButton.addEventListener('click', function(){
        //GEtting the current row
        var tableRows = document.getElementsByTagName("tr")
        var i;
        for( i = 1; i < tableRows.length; i++){
            if(tableRows[i].contains(deleteUserButton)){
                var param = i
            }
        }
         //Getting all the information about a user
         var User = []
         var i = 0
         var cells =  tableRows[param].cells
         for( k = 1; k < cells.length - 2; k++){
             User[i] = cells[k].firstChild.value.toString()
             i++
         }
         var check = confirm(`Would you like to delete ${User[0]} ${User[1]}?`)
        if(check == true){
         //Sending Server Request
         const Http = new XMLHttpRequest();
         const url=`http://localhost:5014/delete/${User[6]}`;
         Http.open("GET", url);
         Http.send();
         Http.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                if(Http.responseText == 1){
                    alert("User Deleted Successfuly!")
                    myTable.deleteRow(param)
                }else{
                    alert("User Deleted Failed...")
                }
            }}
        }
    })
    var element = "UpdateButton" + Count
    var updateUserButton = document.getElementById(element)
    updateUserButton.addEventListener('click', function(){
        try{
        //Finding the current Row
        var tableRows = document.getElementsByTagName("tr")
        var i;
        for( i = 1; i < tableRows.length; i++){
            if(tableRows[i].contains(updateUserButton)){
                var param = i
            }
        }

        //Getting all the information about a user
        var User = []
        var i = 0
        var cells =  tableRows[param].cells
        for( k = 1; k < cells.length - 2; k++){
            User[i] = cells[k].firstChild.value.toString()
            i++
        }
        //Creating a User Object
        var newUser = {
            FirstName: User[0],
            LastName: User[1],
            Address: User[2],
            PhoneNumber: User[3],
            Type: User[4],
            Group: User[5],
            ID: User[6]
        }
        newUser = valueCheck(newUser)
         //Sending Server Request
         var check = confirm(`Would you like to update ${User[0]} ${User[1]}?`)
         if(check == true){
            const Http = new XMLHttpRequest();
            const url=`http://localhost:5014/update/${newUser.ID}&${newUser.FirstName}&${newUser.LastName}&${newUser.Address}&${newUser.PhoneNumber}&${newUser.Type}&${newUser.Group}`;
            Http.open("GET", url);
            Http.send();
            Http.onreadystatechange = function(){
                if(this.readyState == 4 && this.status == 200){
                    if(Http.responseText == 1){
                        alert("User Updated Successfuly")
                    } else{
                        alert("User Failed to update...")
                    }
                    //myTable.deleteRow(param)
                    //getUser(newUser.ID)
                }
            }
        }
        } catch(err){
            alert(err)
        }
    })
}

populateOptions()